/*   $Source: bitbucket.org:berkeleylab/gasnet.git/tests/testtoolscxx.cc $
 * Description: General GASNet correctness tests in C++
 * Copyright 2002, Dan Bonachea <bonachea@cs.berkeley.edu>
 * Terms of use are as specified in license.txt
 */

#include "testtools.c"
